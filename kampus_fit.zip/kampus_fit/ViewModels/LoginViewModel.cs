﻿using System.ComponentModel.DataAnnotations;

namespace kampus_fit.ViewModels
{
    public class LoginViewModel
    {
        [Display(Name = "E-Posta Adresi")]
        [Required(ErrorMessage = "E-Posta alanı zorunludur.")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Şifre")]
        [Required(ErrorMessage = "Şifre alanı zorunludur.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "Beni Hatırla")]
        public bool RememberMe { get; set; }
    }
}