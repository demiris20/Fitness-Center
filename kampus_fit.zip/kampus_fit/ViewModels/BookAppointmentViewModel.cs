﻿using System.ComponentModel.DataAnnotations;

namespace kampus_fit.ViewModels
{
    public class BookAppointmentViewModel
    {
        public int TrainerId { get; set; }
        public int ServiceId { get; set; }

        public string TrainerName { get; set; }
        public string ServiceName { get; set; }
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Lütfen bir tarih ve saat seçiniz.")]
        [Display(Name = "Randevu Tarihi")]
        public DateTime AppointmentDate { get; set; }
    }
}