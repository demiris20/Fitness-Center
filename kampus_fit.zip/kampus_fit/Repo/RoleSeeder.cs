﻿using kampus_fit.Models;
using Microsoft.AspNetCore.Identity;

namespace kampus_fit.Repo
{
    public static class RoleSeeder
    {
        public static async Task SeedRolesAndAdminAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<AppUser>>();

            string[] roleNames = { "Admin", "Member" };

            // 1. Rolleri oluştur (Eğer yoksa)
            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // 2. Admin Kullanıcısını oluştur (Eğer yoksa)
            var adminEmail = "admin@kampusfit.com";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);

            if (adminUser == null)
            {
                var newAdmin = new AppUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    FirstName = "Süper",
                    LastName = "Yönetici",
                    EmailConfirmed = true
                };

                // Şifresi: Sau123!
                var createPowerUser = await userManager.CreateAsync(newAdmin, "Sau123!");

                if (createPowerUser.Succeeded)
                {
                    // Kullanıcıya Admin rolünü ata
                    await userManager.AddToRoleAsync(newAdmin, "Admin");
                }
            }
        }
    }
}