﻿namespace kampus_fit.Models
{
    public class Service
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Duration { get; set; } // <--- Bu eksik olduğu için SeedData hata veriyor.
    }
}