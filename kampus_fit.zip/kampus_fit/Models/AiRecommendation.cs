﻿using System;

namespace kampus_fit.Models
{
    public class AiRecommendation
    {
        public int Id { get; set; }

        // Burayı da AppUser'a bağlıyoruz
        public string MemberId { get; set; }
        public AppUser Member { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public string InputData { get; set; } = "";
        public string RecommendationText { get; set; } = "";
        public string? GeneratedImageUrl { get; set; }
    }
}