﻿namespace kampus_fit.Models
{
    public class FitnessCenter
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }

        // --- Yeni Eklediğimiz Alanlar ---
        public string ContactPhone { get; set; }
        public string OpeningHours { get; set; }
        // --------------------------------

        // İlişkiler
        public List<Service> Services { get; set; } = new List<Service>();
        public List<Trainer> Trainers { get; set; } = new List<Trainer>();
    }
}