﻿using System.ComponentModel.DataAnnotations;
using kampus_fit.Models; // AppUser ve Trainer sınıflarını tanıması için

namespace kampus_fit.Models
{
    public class Appointment
    {
        public int Id { get; set; }

        // Randevu Tarihi ve Saati
        public DateTime AppointmentDate { get; set; }

        // Randevu Oluşturulma Tarihi
        public DateTime CreatedDate { get; set; }

        // Durum (Onay Bekliyor, Onaylandı vs.)
        // DİKKAT: Burası string olmalı çünkü Controller'da düz yazı gönderiyoruz.
        public string Status { get; set; }

        // --- İLİŞKİLER ---

        // 1. Randevuyu alan öğrenci (AppUser)
        public string AppUserId { get; set; }
        public AppUser AppUser { get; set; }

        // 2. Eğitmen
        public int TrainerId { get; set; }
        public Trainer Trainer { get; set; }

        // 3. Ders (Hizmet)
        public int ServiceId { get; set; }
        public Service Service { get; set; }
    }
}