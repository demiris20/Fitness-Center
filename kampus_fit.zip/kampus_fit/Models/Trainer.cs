﻿namespace kampus_fit.Models
{
    public class Trainer
    {
        public int Id { get; set; }
        public string FullName { get; set; } // Veritabanında bu isimle arıyor
        public string Speciality { get; set; }
        public int Experience { get; set; }
        public string ImageUrl { get; set; } = "default.jpg";
    }
}