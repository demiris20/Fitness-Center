﻿using Microsoft.EntityFrameworkCore;
using kampus_fit.Repo;

namespace kampus_fit.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new GymDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<GymDbContext>>()))
            {
                // Veritabanı yoksa oluştur
                context.Database.EnsureCreated();

                // 1. EĞİTMEN KONTROLÜ
                // Eğer veritabanında hiç eğitmen yoksa ekle
                if (!context.Trainers.Any())
                {
                    context.Trainers.AddRange(
                        new Trainer { FullName = "Ali Yılmaz", Speciality = "Vücut Geliştirme", Experience = 5, ImageUrl = "trainer1.jpg" },
                        new Trainer { FullName = "Ayşe Demir", Speciality = "Yoga & Pilates", Experience = 3, ImageUrl = "trainer2.jpg" },
                        new Trainer { FullName = "Mehmet Kaya", Speciality = "Crossfit", Experience = 4, ImageUrl = "trainer3.jpg" }
                    );
                    context.SaveChanges(); // Önce bunları kaydet
                }

                // 2. HİZMET (DERS) KONTROLÜ
                // Eğer veritabanında hiç hizmet yoksa ekle
                if (!context.Services.Any())
                {
                    context.Services.AddRange(
                        new Service { Name = "Birebir Fitness", Duration = 60, Price = 500 },
                        new Service { Name = "Yoga Seansı", Duration = 45, Price = 300 },
                        new Service { Name = "Pilates Dersi", Duration = 50, Price = 400 },
                        new Service { Name = "Crossfit Antrenmanı", Duration = 60, Price = 450 }
                    );
                    context.SaveChanges();
                }
            }
        }
    }
}