using kampus_fit.Models;
using kampus_fit.Repo;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1. Veritaban� Ba�lant�s�
builder.Services.AddDbContext<GymDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2. Identity Ayarlar�
builder.Services.AddIdentity<AppUser, IdentityRole>(options =>
{
    // Geli�tirme a�amas�nda �ifre kurallar�n� gev�ettik (Kolay giri� i�in)
    options.Password.RequireDigit = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 3;
    options.User.RequireUniqueEmail = true;
})
.AddEntityFrameworkStores<GymDbContext>()
.AddDefaultTokenProviders();

// 3. MVC Servisleri
builder.Services.AddControllersWithViews();

var app = builder.Build();

// 4. Hata Y�netimi
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// 5. Yetkilendirme Zinciri
app.UseAuthentication(); // Kimsin?
app.UseAuthorization();  // Yetkin var m�?

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// --- 6. VER� BA�LATMA ---
// Bu k�s�m veritaban� bo�sa �rnek verileri ekler.
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        // �NCEK� ADIMDA VERD���M 'SeedData.cs' DOSYASINI BURADA �ALI�TIRIYORUZ
        kampus_fit.Models.SeedData.Initialize(services);

        // D�KKAT: E�er projenin 'Repo' klas�r�nde 'RoleSeeder.cs' yoksa alttaki sat�r hata verir.
        // O y�zden �imdilik yorum sat�r� yapt�m. Proje �al���nca a�abilirsin.
        // await kampus_fit.Repo.RoleSeeder.SeedRolesAndAdminAsync(services);
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Veritaban� ba�lat�l�rken hata olu�tu.");
    }
}
// ---------------------------------------------

app.Run();