﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using kampus_fit.Models;
using kampus_fit.Repo;
using System.Security.Claims;

namespace kampus_fit.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly GymDbContext _context;

        public AppointmentController(GymDbContext context)
        {
            _context = context;
        }

        // 1. ADIM: Eğitmen Seçimi (Hizmet Seçildikten Sonra Burası Çalışır)
        [HttpGet]
        public async Task<IActionResult> SelectTrainer(int serviceId)
        {
            var service = await _context.Services.FindAsync(serviceId);
            if (service == null) return NotFound();

            // Tüm eğitmenleri getiriyoruz
            var trainers = await _context.Trainers.ToListAsync();

            // Seçilen hizmetin bilgisini View'a (sayfaya) taşıyoruz
            ViewBag.ServiceId = serviceId;
            ViewBag.ServiceName = service.Name;

            return View(trainers);
        }

        // 2. ADIM: Randevu Tarihi Belirleme (Eğitmen de Seçildikten Sonra)
        [HttpGet]
        public IActionResult Book(int trainerId, int serviceId)
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }

            var trainer = _context.Trainers.Find(trainerId);
            var service = _context.Services.Find(serviceId);

            if (trainer == null || service == null) return NotFound();

            var model = new Appointment
            {
                TrainerId = trainerId,
                ServiceId = serviceId,
                Trainer = trainer,
                Service = service,
                AppointmentDate = DateTime.Now.AddDays(1) // Varsayılan: Yarın
            };

            return View(model);
        }

        // 3. ADIM: Randevuyu Veritabanına Kaydetme (GÜNCELLENEN KISIM)
        [HttpPost]
        public async Task<IActionResult> Book(Appointment appointment)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Eğer userId null gelirse (nadiren olur), login sayfasına atalım
            if (string.IsNullOrEmpty(userId)) return RedirectToAction("Login", "Account");

            // --- ÇAKIŞMA KONTROLÜ (CONFLICT CHECK) ---
            // Veritabanında bu eğitmenin, seçilen tarih ve saatte başka bir randevusu var mı?
            bool isConflict = await _context.Appointments.AnyAsync(a =>
                a.TrainerId == appointment.TrainerId &&
                a.AppointmentDate == appointment.AppointmentDate);

            if (isConflict)
            {
                // Hata mesajı oluştur
                ViewBag.Error = "⚠️ Üzgünüz! Bu eğitmenin seçtiğiniz saatte zaten bir randevusu var. Lütfen farklı bir saat seçin.";

                // Sayfanın bozulmaması için Eğitmen ve Hizmet bilgilerini tekrar yüklüyoruz
                var trainer = await _context.Trainers.FindAsync(appointment.TrainerId);
                var service = await _context.Services.FindAsync(appointment.ServiceId);

                appointment.Trainer = trainer;
                appointment.Service = service;

                // Kaydetmeden sayfayı hata mesajıyla geri döndür
                return View(appointment);
            }
            // -----------------------------------------

            appointment.AppUserId = userId;
            // Enum hatası almamak için ToString() kullandık veya "Pending" atadık
            appointment.Status = AppointmentStatus.Pending.ToString();
            appointment.CreatedDate = DateTime.Now;

            // Formdan gelen Trainer ve Service nesneleri bazen boş gelebilir, ID yeterlidir.
            // EF Core hatası almamak için navigation propertyleri null bırakalım (sadece ID'ler dolu olsun)
            appointment.Trainer = null;
            appointment.Service = null;

            _context.Appointments.Add(appointment);
            await _context.SaveChangesAsync();

            return RedirectToAction("MyAppointments");
        }

        // 4. ADIM: Randevularım Sayfası
        public async Task<IActionResult> MyAppointments()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var appointments = await _context.Appointments
                .Include(a => a.Trainer)
                .Include(a => a.Service)
                .Where(a => a.AppUserId == userId)
                .OrderByDescending(a => a.AppointmentDate) // En yeni en üstte
                .ToListAsync();

            return View(appointments);
        }
    }
}