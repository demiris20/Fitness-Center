﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json; // JSON işlemleri için gerekli
using System.Net.Http.Headers; // HTTP Başlıkları için gerekli

namespace kampus_fit.Controllers
{
    public class RecommendController : Controller
    {
        // 1. Sayfayı Göster
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        // 2. OpenAI API'ye Bağlan ve Cevap Al
        [HttpPost]
        public async Task<IActionResult> Index(int age, string goal, string level)
        {
            // --- AYARLAR ---
            string apiKey = "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"; // <--- KEY'İNİ BURAYA YAPIŞTIR
            string apiUrl = "https://api.openai.com/v1/chat/completions";

            // --- PROMPT (AI'ya göndereceğimiz emir) ---
            // Hedefi Türkçeleştirelim ki AI güzel anlasın
            string goalTr = goal == "weightloss" ? "Kilo vermek" :
                            (goal == "muscle" ? "Kas yapmak" : "Esneklik kazanmak");

            string levelTr = level == "beginner" ? "Başlangıç" :
                             (level == "intermediate" ? "Orta" : "İleri");

            // Yapay zekaya rol veriyoruz
            string prompt = $"Sen dünyaca ünlü bir spor koçusun. " +
                            $"Ben {age} yaşındayım. Spor geçmişim: {levelTr}. Hedefim: {goalTr}. " +
                            $"Bana yapmam gereken antrenmanı ve nedenini samimi bir dille, maddeler halinde kısaca anlat. " +
                            $"Cevabın 300 karakteri geçmesin ve motive edici olsun.";

            // --- HTTP İSTEĞİ HAZIRLAMA ---
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                var requestBody = new
                {
                    model = "gpt-3.5-turbo", // Veya "gpt-4o-mini" kullanabilirsin
                    messages = new[]
                    {
                        new { role = "system", content = "Sen yardımcı bir spor antrenörüsün." },
                        new { role = "user", content = prompt }
                    },
                    max_tokens = 150 // Çok uzun cevap verip kotanı yemesin
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync(apiUrl, content);

                    if (response.IsSuccessStatusCode)
                    {
                        var jsonResponse = await response.Content.ReadAsStringAsync();

                        // Gelen karmaşık JSON cevabını parçalıyoruz
                        using (JsonDocument doc = JsonDocument.Parse(jsonResponse))
                        {
                            string aiResponse = doc.RootElement
                                .GetProperty("choices")[0]
                                .GetProperty("message")
                                .GetProperty("content")
                                .GetString();

                            // View'a gönderiyoruz
                            ViewBag.Suggestion = aiResponse;
                            ViewBag.Reason = "Bu öneri Yapay Zeka (OpenAI) tarafından kişisel verilerine göre özel olarak hazırlandı.";
                            ViewBag.ShowResult = true;
                        }
                    }
                    else
                    {
                        // Hata olursa
                        ViewBag.Suggestion = "Üzgünüm, şu an AI servisine ulaşamıyorum.";
                        ViewBag.Reason = "Hata Kodu: " + response.StatusCode;
                        ViewBag.ShowResult = true;
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Suggestion = "Bir hata oluştu.";
                    ViewBag.Reason = ex.Message;
                    ViewBag.ShowResult = true;
                }
            }

            return View();
        }
    }
}