﻿using kampus_fit.Models;
using kampus_fit.Repo;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace kampus_fit.Controllers
{
    [Authorize(Roles = "Admin")] // Sadece admin ulaşsın
    public class AdminController : Controller
    {
        private readonly GymDbContext _context;

        public AdminController(GymDbContext context)
        {
            _context = context;
        }

        // 1. TÜM RANDEVULARI VE İSTATİSTİKLERİ LİSTELE
        public async Task<IActionResult> Index()
        {
            // Veritabanından verileri çek (İlişkili tablolarla birlikte)
            var allAppointments = await _context.Appointments
                                            .Include(a => a.AppUser) // Öğrenci Bilgisi
                                            .Include(a => a.Service) // Ders Bilgisi
                                            .Include(a => a.Trainer) // Eğitmen Bilgisi
                                            .OrderByDescending(a => a.AppointmentDate)
                                            .ToListAsync();

            // --- İSTATİSTİKLERİ HESAPLA ---
            // NOT: AppointmentController "Pending" (Bekliyor) olarak kaydettiği için
            // burada da "Pending" arıyoruz. Türkçe yaparsak eşleşmez.

            // 1. Toplam Randevu Sayısı
            ViewBag.TotalAppointments = allAppointments.Count;

            // 2. Onay Bekleyen Sayısı ("Pending" olanlar)
            ViewBag.PendingCount = allAppointments.Count(a => a.Status == "Pending");

            // 3. Toplam Kazanç (Sadece 'Confirmed' yani Onaylandı olanların fiyatı)
            ViewBag.TotalRevenue = allAppointments
                                   .Where(a => a.Status == "Confirmed" && a.Service != null)
                                   .Sum(a => a.Service.Price);

            return View(allAppointments);
        }

        // 2. RANDEVUYU ONAYLA (View'deki buton: ApproveAppointment)
        [HttpPost]
        public async Task<IActionResult> ApproveAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment != null)
            {
                // Durumu "Confirmed" (Onaylandı) yapıyoruz
                appointment.Status = "Confirmed";
                await _context.SaveChangesAsync();
            }
            // İşlem bitince listeye geri dön
            return RedirectToAction(nameof(Index));
        }

        // 3. RANDEVUYU SİL / REDDET (View'deki buton: DeleteAppointment)
        [HttpPost]
        public async Task<IActionResult> DeleteAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment != null)
            {
                // Veritabanından tamamen siliyoruz (İstersen durumu "Rejected" da yapabilirsin)
                _context.Appointments.Remove(appointment);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}