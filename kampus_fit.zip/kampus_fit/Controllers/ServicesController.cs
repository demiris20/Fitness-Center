﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using kampus_fit.Repo;

namespace kampus_fit.Controllers // <-- BURASI ÇOK ÖNEMLİ
{
    public class ServicesController : Controller
    {
        private readonly GymDbContext _context;

        public ServicesController(GymDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Services.ToListAsync());
        }
    }
}