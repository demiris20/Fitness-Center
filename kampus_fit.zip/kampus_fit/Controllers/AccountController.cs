﻿using kampus_fit.Models;
using kampus_fit.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace kampus_fit.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;

        // Yapıcı Metot (Dependency Injection)
        // Burada Identity sisteminin yöneticilerini çağırıyoruz.
        public AccountController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        // 1. KAYIT OL (Sayfayı Göster)
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // 1. KAYIT OL (Form Gönderilince Çalışır)
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new AppUser
                {
                    UserName = model.Email, // Kullanıcı adı olarak e-posta kullanıyoruz
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName
                };

                // Kullanıcıyı oluştur
                var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    // Başarılıysa hemen giriş yap ve anasayfaya gönder
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");
                }

                // Hata varsa (örn: şifre çok basit), hataları ekrana yaz
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(model);
        }

        // 2. GİRİŞ YAP (Sayfayı Göster)
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // 2. GİRİŞ YAP (Form Gönderilince Çalışır)
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, false);

                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Home");
                }

                ModelState.AddModelError("", "E-posta veya şifre hatalı.");
            }
            return View(model);
        }

        // 3. ÇIKIŞ YAP
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}