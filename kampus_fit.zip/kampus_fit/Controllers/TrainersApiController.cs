﻿using Microsoft.AspNetCore.Mvc;
using kampus_fit.Models;
using kampus_fit.Repo;
using Microsoft.EntityFrameworkCore;

namespace kampus_fit.Controllers
{
    // Bu satır, buranın bir API olduğunu belirtir
    // Adres: senin-site-adresin/api/trainersapi
    [Route("api/[controller]")]
    [ApiController]
    public class TrainersApiController : ControllerBase
    {
        private readonly GymDbContext _context;

        public TrainersApiController(GymDbContext context)
        {
            _context = context;
        }

        // 1. TÜM EĞİTMENLERİ LİSTELE (JSON FORMATINDA)
        // GET: api/trainersapi
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Trainer>>> GetTrainers()
        {
            // Veritabanındaki tüm eğitmenleri JSON (yazı) olarak döndürür
            return await _context.Trainers.ToListAsync();
        }

        // 2. ID'YE GÖRE TEK BİR EĞİTMEN GETİR
        // GET: api/trainersapi/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Trainer>> GetTrainer(int id)
        {
            var trainer = await _context.Trainers.FindAsync(id);

            if (trainer == null)
            {
                return NotFound(); // Bulunamazsa 404 hatası ver
            }

            return trainer;
        }
    }
}